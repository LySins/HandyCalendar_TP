﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RazorCringe.Pages
{
    public class RegistrModel : PageModel
    {
        private readonly ILogger<RegistrModel> _logger;

        public RegistrModel(ILogger<RegistrModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
        }
    }
}
