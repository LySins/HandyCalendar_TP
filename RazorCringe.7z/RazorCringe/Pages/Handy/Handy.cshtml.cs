using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RazorCringe.Models;

namespace RazorCringe.Pages.Handy
{
    public class HandyModel : PageModel
    {

        [BindProperty]
        public EventModel Events { get; set; }

        public List<EventModel> fakeEventDB = new List<EventModel>()
        {
            new EventModel(){Text="Chernyshev Birthday", Day=14,Month=6},

            new EventModel(){Text="desfd",Day=12,Month=9}
        };

        private readonly ILogger<HandyModel> _logger;

        public HandyModel(ILogger<HandyModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
        }

        //public IActionResult OnPost()
        //{

        //}

    }
}
